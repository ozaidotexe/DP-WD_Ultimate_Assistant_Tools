document.addEventListener('DOMContentLoaded', () => {
    const keys = Array.from({ length: 9 }, (_, i) => `ext${i + 1}_active`);
    keys.push('custom_base_domain'); // Tambahkan key untuk domain

    const domainInput = document.getElementById('base_domain_input');
    const saveBtn = document.getElementById('save_domain_btn');

    // Load data tersimpan saat popup dibuka
    browser.storage.local.get(keys).then((res) => {
        // Load URL domain jika ada
        if (res.custom_base_domain) {
            domainInput.value = res.custom_base_domain;
        } else {
            domainInput.value = "https://raj.1lg878-596l.com"; // Default awal
        }

        // Load status sakelar 1 - 9
        keys.forEach((key, index) => {
            if (key !== 'custom_base_domain') {
                const num = index + 1;
                const checkbox = document.getElementById(`ext${num}_switch`);
                if (checkbox) {
                    checkbox.checked = res[key] !== undefined ? res[key] : true;
                    
                    checkbox.addEventListener('change', (e) => {
                        const updateObj = {};
                        updateObj[key] = e.target.checked;
                        browser.storage.local.set(updateObj);
                    });
                }
            }
        });
    });

    // Simpan Domain Saat Tombol Klik
    saveBtn.addEventListener('click', () => {
        let domainValue = domainInput.value.trim();
        // Hapus tanda slash di akhir jika tidak sengaja terketik
        if (domainValue.endsWith('/')) {
            domainValue = domainValue.slice(0, -1);
        }
        
        browser.storage.local.set({ custom_base_domain: domainValue }).then(() => {
            saveBtn.innerText = "Tersimpan!";
            saveBtn.style.background = "#28a745";
            setTimeout(() => {
                saveBtn.innerText = "Simpan Domain";
                saveBtn.style.background = "#007bff";
            }, 1500);
        });
    });
});